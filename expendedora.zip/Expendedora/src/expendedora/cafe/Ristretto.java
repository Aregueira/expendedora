package expendedora.cafe;

public class Ristretto extends Cafe{
    
    @Override
    public String getDescripcion() {
        return "Ristretto";
    }

    @Override
    public double getPrecio() {
        return 110;
    }
}
