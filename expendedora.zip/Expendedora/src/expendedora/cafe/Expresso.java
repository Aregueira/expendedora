package expendedora.cafe;
     
public class Expresso extends Cafe{
    
   @Override
    public String getDescripcion() {
        return "Expresso";
    }

    @Override
    public double getPrecio() {
        return 100;
    }

}
