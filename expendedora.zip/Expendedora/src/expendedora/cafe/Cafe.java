package expendedora.cafe;

import expendedora.Bebida;

public abstract class Cafe extends Bebida{
    
    @Override
    public String getClase(){
        return "Cafe";
    }
}