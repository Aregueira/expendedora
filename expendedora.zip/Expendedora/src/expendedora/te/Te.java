package expendedora.te;

import expendedora.Bebida;

public abstract class Te extends Bebida{
    
    @Override
    public String getClase(){
    return "Te";
    }
}