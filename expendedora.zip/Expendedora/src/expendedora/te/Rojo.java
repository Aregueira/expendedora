package expendedora.te;

public class Rojo extends Te{
    
    @Override
    public String getDescripcion() {
        return "Rojo";
    }

    @Override
    public double getPrecio() {
        return 70;
    }
}
