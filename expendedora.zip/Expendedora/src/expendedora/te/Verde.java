package expendedora.te;

public class Verde extends Te{
    
    @Override
    public String getDescripcion() {
        return "Verde";
    }

    @Override
    public double getPrecio() {
        return 75;
    }
    }