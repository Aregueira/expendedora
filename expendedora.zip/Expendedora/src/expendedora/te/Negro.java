package expendedora.te;

public class Negro extends Te{
    
    @Override
    public String getDescripcion() {
        return "Negro";
    }

    @Override
    public double getPrecio() {
        return 70;
    }  
}
    